//
//  RMSMTileProjection.h
//  MapView
//
//  Created by iclient on 13-6-9.
//
//

#import <Foundation/Foundation.h>
#import "RMMercatorToTileProjection.h"
#import "RMSMLayerInfo.h"
#import "RMSMTileProjection.h"

@class RMProjection;

@interface RMSMTileProjection()
{
  
}
@property(strong,nonatomic)NSDictionary* orinXY;
@end
@interface RMSMTileProjection(inner)

@end