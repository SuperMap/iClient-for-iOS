//
//  ToolKit.h
//  MapView
//
//  Created by imobile-xzy on 16/3/23.
//
//

#import <Foundation/Foundation.h>

@interface ToolKit : NSObject
+(BOOL)createFileDirectories:(NSString*)path;
@end
