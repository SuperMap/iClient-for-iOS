//
//  NSObject+SMTianDiTu_cva_c_TileSource.h
//  MapView
//
//  Created by zhoushibin on 15-4-20.
//
//

#import <Foundation/Foundation.h>
#import "SMTianDiTuTileSource.h"

/**
 * Class: SMTianDiTu_cva_c_TileSource
 * 对接天地图接口，用法参照案例sample目录下tianditu范例
 */
@interface SMTianDiTu_cva_c_TileSource: SMTianDiTuTileSource
{
}
@end
