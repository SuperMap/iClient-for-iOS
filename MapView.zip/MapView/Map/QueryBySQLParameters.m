//
//  QueryBySQLParameters.m
//  MapView
//
//  Created by iclient on 13-6-27.
//
//

#import "QueryBySQLParameters.h"

@implementation QueryBySQLParameters

-(id) init
{
    if (![super init])
		return nil;
    
    return self;
}
@end
