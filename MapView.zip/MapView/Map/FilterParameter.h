//
//  FilterParameter.h
//  MapView
//
//  Created by iclient on 13-6-25.
//
//

#import <Foundation/Foundation.h>
#import "JoinItem.h"
#import "LinkItem.h"

/**
 * Class: FilterParameter
 * 查询过滤条件参数类。
 * 该类用于设置查询数据集的查询过滤参数。
 */
@interface FilterParameter : NSObject

{
    NSString* attributeFilter;
    NSString* name;
    NSMutableArray* joinItems;
    NSMutableArray* linkItems;
    NSMutableArray* ids;
    NSString* orderBy;    
    NSString* groupBy;
    NSMutableArray* fields;
}

/**
 * APIProperty: attributeFilter
 * {NSString} 属性过滤条件。
 * 相当于 SQL 语句中的 WHERE 子句，其格式为：WHERE <条件表达式>，
 * attributeFilter 就是其中的“条件表达式”。
 * 该字段的用法为 attributeFilter = "过滤条件"。
 * 例如，要查询字段 fieldValue 小于100的记录，设置 attributeFilter = "fieldValue < 100"；
 * 要查询字段 name 的值为“酒店”的记录，设置 attributeFilter = "name like '%酒店%'"，等等。
 */
@property (copy,readwrite) NSString* attributeFilter;

/**
 * APIProperty: name
 * {NSString} 查询数据集名称或者图层名称，根据实际的查询对象而定，必设属性。
 * 一般情况下该字段为数据集名称，但在进行与地图相关功能的操作时，
 * 需要设置为图层名称（图层名称格式：数据集名称@数据源别名）。
 * 因为一个地图的图层可能是来自于不同数据源的数据集，
 * 而不同的数据源中可能存在同名的数据集，
 * 使用数据集名称不能唯一的确定数据集，
 * 所以在进行与地图相关功能的操作时，该值需要设置为图层名称。
 */
@property (copy,readwrite) NSString* name;

/**
 * APIProperty: joinItems
 * {NSMutableArray(<JoinItem>)} 与外部表的连接信息 JoinItem 数组。
 */
@property (retain,readwrite) NSMutableArray* joinItems;

/**
 * APIProperty: linkItems
 * {NSMutableArray(<LinkItem>)} 与外部表的关联信息 LinkItem 数组。
 */
@property (retain,readwrite) NSMutableArray* linkItems;

/**
 * APIProperty: ids
 * {NSMutableArray(NSString)} 查询 id 数组，即属性表中的 SmID 值。
 */
@property (retain,readwrite) NSMutableArray* ids;

/**
 * APIProperty: orderBy
 * {NSString} 查询排序的字段,orderBy的字段须为数值型的。
 * 相当于 SQL 语句中的 ORDER BY 子句，其格式为：ORDER BY <列名>，
 * 列名即属性表中每一列的名称，列又可称为属性，在 SuperMap 中又称为字段。
 * 对单个字段排序时，该字段的用法为 orderBy = "字段名"；
 * 对多个字段排序时，字段之间以英文逗号进行分割，用法为 orderBy = "字段名1, 字段名2"。
 * 例如，现有一个国家数据集，它有两个字段分别为“SmArea”和“pop_1994”，
 * 分别表示国家的面积和1994年的各国人口数量。
 * 如果要按照各国人口数量对记录进行排序，则 orderBy = "pop_1994"；
 * 如果要以面积和人口进行排序，则 orderBy = "SmArea, pop_1994"。
 */
@property (copy,readwrite) NSString* orderBy;

/**
 * APIProperty: groupBy
 * {NSString} 查询分组条件的字段。
 * 相当于 SQL 语句中的 GROUP BY 子句，其格式为：GROUP BY <列名>，
 * 列名即属性表中每一列的名称，列又可称为属性，在 SuperMap 中又称为字段。
 * 对单个字段分组时，该字段的用法为 groupBy = "字段名"；
 * 对多个字段分组时，字段之间以英文逗号进行分割，用法为 groupBy = "字段名1, 字段名2"。
 * 例如，现有一个全球城市数据集，该数据集有两个字段分别为“Continent”和“Country”，
 * 分别表示某个城市所属的洲和国家。
 * 如果要按照国家对全球的城市进行分组， 可以设置 groupBy = "Country"；
 * 如果以洲和国家对城市进行分组，设置 groupBy = "Continent, Country"。
 */
@property (copy,readwrite) NSString* groupBy;

/**
 * APIProperty: fields
 * {NSMutableArray(NSString)} 查询字段数组，如果不设置则使用系统返回的所有字段。
 */
@property (retain,readwrite) NSMutableArray* fields;

- (NSMutableDictionary *)toNSDictionary;
@end
